angular.module('app.routes', [])

.config(function($stateProvider, $urlRouterProvider) {

  // Ionic uses AngularUI Router which uses the concept of states
  // Learn more here: https://github.com/angular-ui/ui-router
  // Set up the various states which the app can be in.
  // Each state's controller can be found in controllers.js
  $stateProvider
    
  

      .state('menu.inicio', {
    url: '/inicio',
    views: {
      'side-menu21': {
        templateUrl: 'templates/inicio.html',
        controller: 'inicioCtrl'
      }
    }
  })

  .state('menu.apagado', {
    url: '/apagado',
    views: {
      'side-menu21': {
        templateUrl: 'templates/apagado.html',
        controller: 'apagadoCtrl'
      }
    }
  })

  .state('menu.sensores', {
    url: '/sensores',
    views: {
      'side-menu21': {
        templateUrl: 'templates/sensores.html',
        controller: 'sensoresCtrl'
      }
    }
  })

  .state('menu', {
    url: '/menu',
    templateUrl: 'templates/menu.html',
    controller: 'menuCtrl'
  })

  .state('inicioSesion', {
    url: '/sesion',
    templateUrl: 'templates/inicioSesion.html',
    controller: 'inicioSesionCtrl'
  })

  .state('menu.graficas', {
    url: '/graficas',
    views: {
      'side-menu21': {
        templateUrl: 'templates/graficas.html',
        controller: 'graficasCtrl'
      }
    }
  })

  .state('menu.tiempo', {
    url: '/tiempo',
    views: {
      'side-menu21': {
        templateUrl: 'templates/tiempo.html',
        controller: 'tiempoCtrl'
      }
    }
  })

$urlRouterProvider.otherwise('/menu/inicio')

  

});